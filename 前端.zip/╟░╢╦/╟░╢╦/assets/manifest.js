
(function() {

    if(!window.ZY) {
        window.ZY = {};
    }

    window.ZY = {


        Loading: function() {

            var xishu = 0.15;
            var img_src = "";
            var height = 0.15 * document.documentElement.clientWidth;
            var top = (document.documentElement.clientHeight - 0.15 * document.documentElement.clientWidth) / 2;
            var imgheight = "15%";
            var imgwidth = "80%";
            var imgleft = "10%";
            var div_back = true;

            var setshuzhi = function(value) {

                if(value.div_width) {
                    xishu = value.div_width;
                    height = xishu * document.documentElement.clientWidth;
                    top = (document.documentElement.clientHeight - xishu * document.documentElement.clientWidth) / 2;
                }

                if(!value.back && value.back == false) {
                    div_back = value.back;
                }

                if(value.img_src) {
                    img_src = value.img_src;
                }

                if(value.img_height) {
                    imgheight = (value.img_height * 100) + "%";
                }

                if(value.img_width) {
                    imgwidth = (value.img_width * 100) + "%";
                    imgleft = (((1 - value.img_width) * 100) / 2) + "%";
                }

                if(value.start && value.start == true) {
                    start();
                }

            };

            var start = function() {
                //console.log('loading start');
                var loading = document.getElementById('loadingdiv');
                if(loading) {
                    //如果已经有了,为了防止重复,先删掉
                    document.body.removeChild(loading);
                }

                //先创建背景div

                var back_div = document.createElement('div');
                back_div.style.position = 'fixed';
                back_div.style.width = height + 'px';
                back_div.style.height = height + 'px';
                back_div.style.left = (document.documentElement.clientWidth - height) / 2 + 'px';
                back_div.style.top = top + 'px';
                if(div_back == true) {
                    back_div.style.backgroundColor = "rgba(0,0,0,0.5)";
                }
                back_div.style.zIndex = '9999';
                back_div.style.display = 'flex';
                back_div.style.justifyContent = "center";
                back_div.style.flexDirection = "column";
                back_div.id = 'loadingdiv';
                document.body.appendChild(back_div);

                var loading_img = document.createElement('img');
                loading_img.src = img_src;
                loading_img.style.width = imgwidth;
                loading_img.style.marginLeft = imgleft;
                loading_img.style.height = imgheight;
                document.getElementById('loadingdiv').appendChild(loading_img);

            };

            var end = function() {
                //console.log('loading end');
                var loading = document.getElementById('loadingdiv');
                if(loading) {
                    //如果已经有了,为了防止重复,先删掉
                    document.body.removeChild(loading);
                }
            };

            return {
                set: setshuzhi,
                start: start,
                end: end
            }
        },

    };
})();


var loading=new ZY.Loading();
loading.set({
    img_src:'images/loading.gif'
});



